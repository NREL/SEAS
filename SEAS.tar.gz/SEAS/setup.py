import os
from setuptools import setup

with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'requirements.txt'), 'r') as f:
    requirements = f.read().split()

setup(
    name="SEAS",
    version="0.1",
    install_requires=requirements,
    packages=["SEAS"]
)