import json
import os

from SEAS.helics_connector import HelicsConnector
from SEAS.federate_agent_base import FederateAgentBase

def read_assign_config(obj, source, type="file"):
    """Assign the specified attributes to the target object.

    If the type is "file", source is treated as the path to a json file containing the attributes
    to be assigned.

    If the type is "dict", source is treated as a dictionary of the attributes.

    Args:
        obj: the target object
        source: the source of the attributes to be assigned
        type: the type of the source
    """
    if type == "file":
        f = open(source, "r")
        data = f.read()
        source_config = json.loads(data)
        obj.__dict__.update(source_config)
    elif type == "dict": 
        obj.__dict__.update(source)


class FederateAgent(FederateAgentBase):
    """Base class representing a single federate for use in helics.

    This class handles basic communication via helics as well as the mechanics of running 
    the simulation's time steps. For application-specific behavior, create a subclass
    containing the application-specific logic.
    """

    def __init__(self,name,feeder_num=0,starttime=0, endtime=0, agent_num=0, config_dict=None, config_file=None, **kwargs):
        """Create a new federateagent.

        The combination of name and feeder_num values must be unique within the simulation.

        Args:
            name: the name used to identify the agent
            feeder_num: ?
            starttime: ?
            endtime: the helics timestep at which the agent should stop running its simulation
            config_dict: the configuration values for the agent
        """

        self.name = name        
        self.feeder_num = feeder_num
        self.starttime =  starttime
        self.endtime = endtime

        if config_dict is not None and config_dict.get("helics", {}).get("deltat") is not None:
            self.deltat  = config_dict['helics']['deltat']
        else:
            self.deltat = 1.0

        if config_dict is not None:
            read_assign_config(self, config_dict, "dict")
        elif config_file is not None:
            read_assign_config(self, config_file, "file")

    def run_helics_setup(self, broker_params={}):
        """Create a new helics federate and initialize any necessary connections to the broker.

        Uses the agent's "helics" configuration to determine which topics and endpoints to attach to.

        Args:
            broker_params: a dict of keyword args to pass to the HelicsConector's connect() function
        """

        self.absolute_helics_time = 0.0
        self.name_helics = "{}_{}".format(self.feeder_num, self.name)

        broker_params['broker_port'] = os.getenv('HELICS_PORT', '32000')
        broker_params['broker_address'] = os.getenv('HELICS_HOST', '127.0.0.1')

        self.helics_connector = HelicsConnector(self.name_helics, self.deltat, **broker_params)
        self.helics_connector.connect(self.helics.get('publication_topics'), 
            self.helics.get('subscription_topics'), self.helics.get('endpoints'))
        
    def enter_execution(self,function_targets= [], function_arguments=[[]]):
        """Run the federate's full simulation.
        """

        self.helics_connector.enter_executing_mode()
        self.run()

    def run(self):
        """Run the federate's full simulation.

        Connects to the helics broker after each step in order to synchronize time.
        At each time step, takes any appropriate publish and subscribe actions via
        the helics broker.
        """

        self.publish_initial_helics_data()

        while self.absolute_helics_time < self.endtime:
            self.sync_time_helics(self.absolute_helics_time + self.deltat)

            if (self.absolute_helics_time < self.starttime):
                continue
    
            incoming_messages = self.helics_connector.get_all_waiting_messages()
            if incoming_messages != {}:
                self.process_subscription_messages(incoming_messages)

            tmp = self.helics_connector.receive_from_endpoints()
            if tmp != []:
                self.process_endpoint_event(tmp)
            if self.absolute_helics_time%self.publication_interval==0:
                self.process_periodic_publication()
            if self.absolute_helics_time%self.endpoint_interval==0:
                self.send_periodic_endpoint_messages()
                
    def send_via_helics(self, topic, message):
        """Send a message to a particular topic on the helics bus.
        
        Adds any necessary metadata that the receiving end may expect.

        Args:
            topic: the helics topic to send the message on
            message: a string representing the message to send
        """
        message = {
            'message': message, 
            'source' : self.name_helics,
            'timestamp': self.absolute_helics_time
        }
        self.helics_connector.helics_put(topic, message)     

    def publish_initial_helics_data(self):
        """Publish any data that should be available on the bus at the first timestep. 
        """
        pass

    def process_periodic_publication(self):
        """Publish data to the helics broker. Must be implemented by a subclass.

        This function is called every publication_interval.
        """
        raise NotImplementedError

    def send_periodic_endpoint_messages(self):
        """Send any necessary endpoint messages. Must be implemented by a subclass."""
        raise NotImplementedError    

    def process_subscription_messages(self, incoming_messages):
        """Take any necessary internal action on an incoming subscription event. Must be implemented by a subclass.
        
        Args:
            incoming_messages: a dictionary of topic name -> message received for the topic
        """
        raise NotImplementedError        

    def process_endpoint_event(self, msg):
        """Take any necessary internal action on an incoming endpoint event. Must be implemented by a subclass."""
        raise NotImplementedError 

    def sync_time_helics(self, next_timestep):
        """Retrieve and store the current timestep in the helics simulation.

        Args:
            next_timestep: the requested timestep from helics
        """
        self.absolute_helics_time = self.helics_connector.update_helics_time(next_timestep)


    def broadcast(self, topic, message):
        """Broadcast the specified topic and message to all helics destinations.

        Args:
            topic: the helics topic to publish to
            message: the message to send
        """
        self.send_via_helics(topic, message)


