from abc import ABC


class FederateAgentBase(ABC):
    """Base class for the FederateAgent class.

    This class is intended to hold methods that are currently unused but may be
    needed in the future.
    """

    def listen_for_messages(self):
        while self.absolute_helics_time < (self.endtime - self.starttime  +1 ):
            self.sync_time_helics(self.deltat)
            tmp = self.helics_connector.get_all_waiting_messages()
            if tmp != []:
                self.process_subscription_messages(tmp)
            else:
                continue

    def listen_for_endpoints(self):
        while self.absolute_helics_time < (self.endtime):
            self.sync_time_helics(self.deltat)
            tmp = self.helics_connector.receive_from_endpoints()
            if tmp != []:
                self.process_endpoint_event(tmp)
            else:
                continue   
    
    def run_model(self):
        """ This must be implemented """
        raise NotImplementedError

        
    def periodic_publications(self):
        while self.absolute_helics_time < self.endtime:
            if self.absolute_helics_time % self.publication_interval == 0.0:
                self.process_periodic_publication()
            self.sync_time_helics(self.publication_interval)
    
    def periodic_endpoints(self):
        while self.absolute_helics_time < self.endtime:
            if self.absolute_helics_time % self.endpoint_interval == 0.0:
                self.send_periodic_endpoint_messages()
            self.sync_time_helics(self.helics['deltat'])