import ast

import helics

from SEAS.helics_connector_base import HelicsConnectorBase


class HelicsConnector(HelicsConnectorBase):
    """Class used by the federate agent in order to encapsulate helics communication.

    This prevents the federate agent from needing to call helics functions directly.
    The goal is to make it easier to mock out helics communication for unit and
    integration testing. 
    """

    DEFAULT_BROKER_PORT = 32000

    def __init__(self, name_helics, deltat, comm_type="zmq", broker_address="127.0.0.1",
                 broker_port=DEFAULT_BROKER_PORT):
        """Create a new HelicsConnector.

        Args:
            name_helics: the name to use when connecting to helics. Must be unique within
                the simulation.
            deltat: the helics timestep for this agent to listen on
            comm_type: the protocol to use for communicating with the helics broker
            broker_address: the address of the helics broker
            broker_port: the port of the helics broker
        """

        self.name_helics = name_helics
        self.deltat = deltat
        self.comm_type = comm_type
        self.broker_address = broker_address
        self.broker_port = broker_port

        self.helics_pub_topics = {}
        self.helics_subscr_topics = {}
        self.helics_endpoints = {}

    def connect(self, pub_topics=None, subscr_topics=None, endpoints=None):
        """Connect to the helics broker and initialize any messaging topics.

        Args:
            pub_topics: list of helics topics to publish to
            subscr_topics: list of topics to subscribe to
            endpoints: list of helics endpoints to expose
        """
        federate_info = helics.helicsCreateFederateInfo()
        helics.helicsFederateInfoSetCoreName(federate_info, self.name_helics)
        helics.helicsFederateInfoSetCoreTypeFromString(
            federate_info, self.comm_type)

        federate_init_str = f"--federates=1 --broker_address={self.broker_address} --brokerport={self.broker_port}"
        # federate_init_str = f"--federates=1 --broker_address={self.broker_address} "
        helics.helicsFederateInfoSetCoreInitString(
            federate_info, federate_init_str)
        helics.helicsFederateInfoSetTimeProperty(federate_info,
                                                 helics.helics_property_time_delta, self.deltat)

        self.combo_federate = helics.helicsCreateCombinationFederate(
            self.name_helics, federate_info)

        for topic in pub_topics or []:
            self.helics_pub_topics[topic] = helics.helicsFederateRegisterGlobalTypePublication(
                self.combo_federate, topic, "string")

        for topic in subscr_topics or []:
            self.helics_subscr_topics[topic] = helics.helicsFederateRegisterSubscription(
                self.combo_federate, topic)

        for endpoint in endpoints or []:
            self.helics_endpoints[endpoint] = helics.helicsFederateRegisterGlobalEndpoint(
                self.combo_federate, endpoint)

    def enter_executing_mode(self):
        """Tell helics that the federate is ready to enter executing mode.
        """
        helics.helicsFederateEnterExecutingMode(self.combo_federate)

    def get_all_waiting_messages(self):
        """Ingest any waiting messages from the helics bus.

        Returns:
            a dict of the waiting messages, by subscription key 
        """

        messages = {}
        for subscription_key, helics_input in self.helics_subscr_topics.items():

            msg = ast.literal_eval(helics.helicsInputGetString(helics_input))
            if type(msg) == dict:
                messages[subscription_key] = msg
            else:  # This code is specific to AMRWind only
                messages[subscription_key] = {"message": msg}

        return messages

    def receive_from_source(self, source, retries_allowed=4):
        """Retrieve the waiting message from a specific helics source.

        Args:
            source: the subscription key of the source
            retries_allowed: the number of times to retry in case of an exception

        Returns:
            the message retrieved from the specified helics source
        """
        for i in range(retries_allowed):
            try:
                msg = helics.helicsInputGetString(
                    self.helics_subscr_topics[source])
                message = ast.literal_eval(msg)
                if message['destination'] == self.name_helics:
                    return (message)
                else:
                    return None
            except:
                pass

    def helics_put(self, topic, message):
        """Send a message to a particular topic over the helics bus.

        Args:
            topic: the topic to publish the message on
            message: the message to send
        """
        helics.helicsPublicationPublishString(
            self.helics_pub_topics[topic], str(message))

    def update_helics_time(self, next_timestep):
        """Retrieve the next timestep in the helics simulation.

        Args:
            next_timestep: the requested timestep from helics
        """
        return helics.helicsFederateRequestTime(self.combo_federate, next_timestep)

    def receive_from_endpoints(self):
        """Retrieve any waiting messages from the agent's helics endpoints.

        Returns:
            a list of any messages that were waiting 
        """
        all_msg = []

        for key, endpoint in self.helics_endpoints.items():
            if helics.helicsEndpointHasMessage(endpoint):
                while True:
                    msg = helics.helicsEndpointGetMessage(endpoint)
                    if msg.data == "":
                        break
                    all_msg.append(msg)
        return (all_msg)

    def send_endpoint_message(self, endpoint, message, destination):
        """Send the specified message to the specified endpoint.

        Args:
            endpoint: the name of the endpoint
            message: the message
            destination: the intended destination
        """
        helics.helicsEndpointSendBytesTo(
            self.helics_endpoints[endpoint], message, destination)
