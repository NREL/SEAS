from abc import ABC

import helics


class HelicsConnectorBase(ABC):
    """Base class for the HelicsConnector class.

    This class is intended to hold methods that are currently unused but may be
    needed in the future.
    """

    def send_endpoint(self, message, name):
        helics.helicsEndpointSendBytesTo(self.en, message, name)

    def send_opendss(self,message):
        helics.helicsEndpointSendBytesTo(self.myendpoint, message,self.myopendss_endpoint)

    def helics_finalize(self):
        helics.helicsFederateFinalize(self.combo_federate)
        helics.helicsFederateFree(self.combo_federate)