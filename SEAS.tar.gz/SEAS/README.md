# SEAS

Package used for connecting external simulations to helics and allowing them to run and communicate with each other in a well-defined way.

Currently a work in progress, contacts are:
- Deepthi Vaidhynathan
- Kinshuk Panda
- Sam Helman