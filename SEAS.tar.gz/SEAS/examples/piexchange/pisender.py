from SEAS.federate_agent import FederateAgent


# Configuration for the federateagent. This could also come from a config
# file, but lives here for easier readability.
AGENT_CONFIG = {
    'helics': {
        'publication_topics': [
            'pi_channel'
        ],
    },

    # publish every timestep
    'publication_interval': 1,

    # set high so that the unimplemented endpoint function never triggers
    'endpoint_interval': 1000,
}


class PiSender(FederateAgent):
    def process_periodic_publication(self):
        self.send_via_helics('pi_channel', '3.14')


def main():
    agent = PiSender('pisender', endtime=10, config_dict=AGENT_CONFIG)
    agent.run_helics_setup()
    agent.enter_execution()


if __name__ == '__main__':
    main()