This is a small working example of using the federate agent class to send
messages over the helics bus. To run the example:

1. Activate a conda environment that has the ``helics`` package installed.
2. Run ``helics_broker --federates 2 --local_port 32000``.
3. In a separate terminal, run ``python pireceiver.py``.
4. In a third terminal, run ``python pisender.py``.  

Expected behavior:
- The simulation runs fully and all three processes exit.
- The pireceiver prints the messages it receives from the sender. 