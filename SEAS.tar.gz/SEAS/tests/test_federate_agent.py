import os

from SEAS.federate_agent import FederateAgent, read_assign_config


def test_read_assign_config():
    agent = FederateAgent("fake_agent", config_dict=dict())
    read_assign_config(agent, {"attr1": "a", "attr2": "b"}, type="dict")
    assert agent.attr1 == "a"
    assert agent.attr2 == "b"

    agent = FederateAgent("fake_agent", config_dict=dict())
    read_assign_config(agent, os.path.join(os.path.dirname(os.path.abspath(__file__)), "agent_config/fake_agent_0.json"),
        type="file")
    assert agent.attr1 == 1
    assert agent.attr2 == 2  
        