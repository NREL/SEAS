pip install pdoc
pdoc --docformat google SEAS