from SEAS.federate_agent import FederateAgent


# Configuration for the federateagent. This could also come from a config
# file, but lives here for easier readability.
AGENT_CONFIG = {
    'helics': {
        'subscription_topics': [
            'pi_channel'
        ],
    },

    # set high so that the unimplemented endpoint and publication functions never trigger
    'endpoint_interval': 1000,
    'publication_interval': 1000,
}


class PiReceiver(FederateAgent):
    def process_subscription_messages(self, incoming_messages):
        pi_channel_message = incoming_messages['pi_channel']
        print(f'PI RECEIVER: Received {pi_channel_message["message"]} at time = {self.absolute_helics_time} from {pi_channel_message["source"]}')


def main():
    agent = PiReceiver('pireceiver', endtime=10, config_dict=AGENT_CONFIG)
    agent.run_helics_setup()
    agent.enter_execution()


if __name__ == '__main__':
    main()